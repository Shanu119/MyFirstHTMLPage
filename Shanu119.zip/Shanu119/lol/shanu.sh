f1=('mango' 255  5)
f2=('banana' 100 10)
f3=('apple' 300 15)

if [ ${f1[1]} -ge 250 ]
then
echo -n "${f1[0]}"
echo  " ${f1[1]}"
else
echo "${f1[0]}"
fi

if [ ${f2[1]} -ge 250 ]
then
echo -n "${f2[0]}"
echo  " ${f2[1]}"
else
echo "${f2[0]}"
fi

if [ ${f3[1]} -ge 250 ]
then
echo -n "${f3[0]}"
echo  " ${f3[1]}"
else
echo "${f3[0]}"
fi