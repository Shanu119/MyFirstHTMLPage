    arr=(1 2 3 3 4 5 5 6 7 8 9 10 11 12 13)
    k=0;
    while [ i=0; i -le 9; i++ ]
    do
        for (( j=9; j>=0; j--))
        do
            if [arr[i]==arr[j]]
            then
             echo "$arr[i]"
             echo "$arr[j]"            
        fi
        done
    done